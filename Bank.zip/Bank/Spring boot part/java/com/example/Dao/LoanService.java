package com.example.Dao;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
@Service
@Transactional
public class LoanService {
	@Autowired
	LoanDAO dao;
	
	public Loan[] showLoan() {
		return dao.showLoan();
	}
	public Loan searchLoan(int loanid) {
		return dao.searchLoan(loanid);
	}
	public Loan[] searchLoanByAccountNo(int accountNumber) {
		return dao.searchLoanByAccountNo(accountNumber);
	}
	public Loan[] searchLoanByStatus(String loanStatus) {
		return dao.searchLoanByStatus(loanStatus);
	}
	public String acceptOrRejectLoan(int loanid,String loanStatus) {
		return dao.acceptOrRejectLoan(loanid, loanStatus);
	}
	public String applyLoan(Loan loan) {
		return dao.applyLoan(loan);
	}
}
