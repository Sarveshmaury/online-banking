import { Component, OnInit } from '@angular/core';
import { Transaction } from '../transaction';
import { TransactionService } from '../transaction.service';

@Component({
  selector: 'app-transaction-show',
  templateUrl: './transaction-show.component.html',
  styleUrls: ['./transaction-show.component.scss']
})
export class TransactionShowComponent implements OnInit {

  transactionss : Transaction[];
  constructor(private _transactionService :TransactionService) {
    this._transactionService.showTransaction().subscribe({
      next: (rs: Transaction[]) =>{
        this.transactionss = rs;
      }
    })
   }

  ngOnInit(): void {
  }

}
