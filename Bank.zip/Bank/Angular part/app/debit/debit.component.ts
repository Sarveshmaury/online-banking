import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Transaction } from '../transaction';
import { TransactionService } from '../transaction.service';
@Component({
  selector: 'app-debit',
  templateUrl: './debit.component.html',
  styleUrls: ['./debit.component.scss']
})
export class DebitComponent implements OnInit {

  result : any;
  res :string;
  insert(placeTransaction : NgForm) {
    this.transaction.accountNumber = this.accountNumber;
    this._transactionService.placeTransaction(this.transaction).subscribe(x =>{
      this.result=x;
    alert(x);
  
  })
  alert(this.result);
}
accountNumber :number;
 tranId : number;

     tranAmount : number;
     tranType : string;
     tranDate : Date;
     transaction:Transaction;


     constructor(private _transactionService:TransactionService 
      ) {this.transaction = new Transaction();
        this.accountNumber = parseInt(localStorage.getItem("accountNumber"));
       // this._walletService.showCustomerWallet(this.cid).subscribe(x => {
         // this.wallets = x;
        //});
       }

  ngOnInit(): void {
  }

}
