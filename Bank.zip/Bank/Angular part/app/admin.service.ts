import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { catchError, tap, map } from 'rxjs/operators';
import { Admin } from './admin';
import { Account } from './account';
@Injectable({
  providedIn: 'root'
})
export class AdminService {

  constructor(private _http: HttpClient) { }
  showAdmin(): Observable<Admin []> {
    return this._http.get<Admin []>("http://localhost:8080/Admins")
      .pipe(
        tap(data =>
        console.log('All: ' + JSON.stringify(data)))
      );
  }
  searchAdmin(adminId : number): Observable<Admin > {
    return this._http.get<Admin >("http://localhost:8080/Admins/"+adminId)
      .pipe(
        tap(data =>
        console.log('All: ' + JSON.stringify(data)))
      );
  }
  showAccount(): Observable<Account []> {
    return this._http.get<Account []>("http://localhost:8080/Accounts")
      .pipe(
        tap(data =>
        console.log('All: ' + JSON.stringify(data)))
      );
  }
}
