export class Account {

   public accountNumber : number;
    public firstName : string;
    public lastName : string;
    public gender : string;
    public city : string;
    public state : string;
    public mob : string;
    public email : string;
    public balance : number;
    public cheqFacil : string;
    public accountType : string;
    public status : string;
    public dateOfOpen : Date;
    constructor(){
}
}
