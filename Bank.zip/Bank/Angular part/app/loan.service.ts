import { Injectable } from '@angular/core';
import { Loan } from './loan';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { catchError, tap, map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class LoanService {

  constructor(private _http: HttpClient) { }
  applyLoan(loan : Loan) : Observable<string> {
    return this._http.post<string>("http://localhost:8080/Loans/New/",loan)
  }
  
  applyLoan1(loan : Loan) : Observable<any> {
    return this._http.post<string>("http://localhost:8080/Loans/New/",loan).
    pipe(tap(data => data.toString()))
  }
  searchLoan(accountNumber : number): Observable<Loan[]> {
    return this._http.get<Loan[]>("http://localhost:8080/Loans/Customers/"+accountNumber)
      .pipe(
        tap(data =>
        console.log('All: ' + JSON.stringify(data)))
      );
  }
  showLoan(): Observable<Loan []> {
    return this._http.get<Loan []>("http://localhost:8080/Loans")
      .pipe(
        tap(data =>
        console.log('All: ' + JSON.stringify(data)))
      );
  }
  showPendingLoan(): Observable<Loan []> {
    return this._http.get<Loan []>("http://localhost:8080/Loans/Status/pending")
      .pipe(
        tap(data =>
        console.log('All: ' + JSON.stringify(data)))
      );
  }
  acceptOrRejectLoan(loanId : number, status : string) : Observable<any>{
    return this._http.post("http://localhost:8080/Loans/Loans/"+loanId+"/"+status,null,{"responseType":'text'})
    .pipe(
      tap(data =>{console.log("apply Loan :"+data.toString());
    return data.toString();})
    );
  }
}

