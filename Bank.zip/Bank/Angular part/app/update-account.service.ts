import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { catchError, tap, map } from 'rxjs/operators';
import { Account } from './account';

@Injectable({
  providedIn: 'root'
})
export class UpdateAccountService {

  constructor(private _http: HttpClient) { }
  updateAccount(account : Account) : Observable<string> {
    return this._http.post<string>
    ("http://localhost:8080/Accounts/Accounts/",account)
  }
  
  updateAccount1(account : Account) : Observable<any> {
    return this._http.post<string>
    ("http://localhost:8080/Accounts/Accounts/",account).
    pipe(tap(data => data.toString()))
  }
  
}
