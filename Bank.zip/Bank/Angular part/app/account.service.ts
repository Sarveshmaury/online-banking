import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { catchError, tap, map } from 'rxjs/operators';
import { Account } from './account';
@Injectable({
  providedIn: 'root'
})
export class AccountService {

  constructor(private _http: HttpClient) { }
  showAccount(): Observable<Account []> {
    return this._http.get<Account []>("http://localhost:8080/Accounts")
      .pipe(
        tap(data =>
        console.log('All: ' + JSON.stringify(data)))
      );
  }
  searchAccount(accountNumber : number): Observable<Account > {
    return this._http.get<Account >("http://localhost:8080/Accounts/Customers/"+accountNumber)
      .pipe(
        tap(data =>
        console.log('All: ' + JSON.stringify(data)))
      );
  }
  showBalance(accountNumber : number): Observable<Account > {
    return this._http.get<Account >("http://localhost:8080/Accounts/Customers/"+accountNumber)
      .pipe(
        tap(data =>
        console.log('All: ' + JSON.stringify(data)))
      );
  }
  addAccount(account : Account) : Observable<string> {
    return this._http.post<string>("http://localhost:8080/Accounts/New/",account)
    .pipe(
      tap(data =>
      console.log('All: ' + JSON.stringify(data)))
    );
  }
}
