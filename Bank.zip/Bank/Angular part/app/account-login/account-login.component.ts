import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Account } from '../account';
import { AccountService } from '../account.service';

@Component({
  selector: 'app-account-login',
  templateUrl: './account-login.component.html',
  styleUrls: ['./account-login.component.scss']
})
export class AccountLoginComponent implements OnInit {

  accountNumber : number;
  passCode : string;
  accounts : Account[];
  logMe() {
    localStorage.setItem('accountNumber',this.accountNumber.toString());
    if(this.passCode=="Mphasis") {
      this._router.navigate(['/accountDashBoard']);
    }
  }
  constructor(private _router : Router, private _accountService :AccountService) { 
    this._accountService.showAccount().subscribe({
      next: rs =>{
        this.accounts = rs;
      }
    })
  }

  ngOnInit(): void {
  }

}
