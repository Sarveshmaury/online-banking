import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, tap } from 'rxjs';
import { Transaction} from './transaction';
import { Account } from './account';

@Injectable({
  providedIn: 'root'
})
export class TransactionService {

  constructor(private _http: HttpClient) { }
  showTransaction(): Observable<Transaction[]> {
    return this._http.get<Transaction[]>("http://localhost:8080/Transactions")
      .pipe(
        tap((data: any) =>
        console.log('All: ' + JSON.stringify(data)))
      );
  } 
  searchTransaction(accountNumber : number): Observable<Transaction[]> {
    return this._http.get<Transaction[]>("http://localhost:8080/Transactions/Customers/"+accountNumber)
      .pipe(
        tap(data =>
        console.log('All: ' + JSON.stringify(data)))
      );
  } 
  placeTransaction(transaction: Transaction) : Observable<string> {
    return this._http.post<string>("http://localhost:8080/Transactions/New  ",transaction)
    .pipe(
      tap(data =>
      console.log('All: ' + JSON.stringify(data)))
    );
  }
  debit(transaction: Transaction) : Observable<string> {
    return this._http.post<string>("http://localhost:8080/Transactions/New  ",transaction)
    .pipe(
      tap(data =>
      console.log('All: ' + JSON.stringify(data)))
    );
  }
  credit(transaction: Transaction) : Observable<string> {
    return this._http.post<string>("http://localhost:8080/Transactions/Transactions ",transaction)
    .pipe(
      tap(data =>
      console.log('All: ' + JSON.stringify(data)))
    );
  }

}
