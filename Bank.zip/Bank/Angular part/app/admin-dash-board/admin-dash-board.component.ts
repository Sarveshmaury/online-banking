import { Component, OnInit } from '@angular/core';
import { Admin } from '../admin';
import { AdminService } from '../admin.service';

@Component({
  selector: 'app-admin-dash-board',
  templateUrl: './admin-dash-board.component.html',
  styleUrls: ['./admin-dash-board.component.scss']
})
export class AdminDashBoardComponent implements OnInit {

  adminId : number;
  admins : Admin;
  constructor(private _adminService : AdminService) { 
    this.adminId =parseInt(localStorage.getItem("adminId"));
    this._adminService.searchAdmin(this.adminId).subscribe(x => {
      this.admins=x;
    })
  }

  ngOnInit(): void {
  }

}
