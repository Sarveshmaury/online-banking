export class Loan {
    public  loanId :number;
	public  accountNumber:number ;
	public  loanAmount:number;
    
	public loanApplyDate:Date ;
    public  loanStatus:String ;
    public  loanApplyFor:String ;

    constructor(){
    }
}
