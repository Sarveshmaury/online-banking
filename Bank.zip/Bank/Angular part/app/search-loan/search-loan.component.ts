import { Component, OnInit } from '@angular/core';
import { Loan } from '../loan';
import { LoanService } from '../loan.service';

@Component({
  selector: 'app-search-loan',
  templateUrl: './search-loan.component.html',
  styleUrls: ['./search-loan.component.scss']
})
export class SearchLoanComponent implements OnInit {

  accountNumber : number;
  loan :Loan[];
  constructor(private _loanService : LoanService) { 
    this.accountNumber =parseInt(localStorage.getItem("accountNumber"));
    this._loanService.searchLoan(this.accountNumber).subscribe({next:rs=>{this.loan=rs;}}
    )
  }


  ngOnInit(): void {
  }

}
