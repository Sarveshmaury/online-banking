import { Component, OnInit } from '@angular/core';
import { Admin } from '../admin';
import { AdminService } from '../admin.service';
@Component({
  selector: 'app-search-admin',
  templateUrl: './search-admin.component.html',
  styleUrls: ['./search-admin.component.scss']
})
export class SearchAdminComponent implements OnInit {

  adminId : number;
  admins : Admin;
  constructor(private _adminService : AdminService) { 
    this.adminId =parseInt(localStorage.getItem("adminId"));
    this._adminService.searchAdmin(this.adminId).subscribe(x => {
      this.admins=x;
    })
  }

  ngOnInit(): void {
  }

}
