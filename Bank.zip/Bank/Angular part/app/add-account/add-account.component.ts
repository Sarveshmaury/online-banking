import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Account } from '../account';
import { AccountService } from '../account.service';
@Component({
  selector: 'app-add-account',
  templateUrl: './add-account.component.html',
  styleUrls: ['./add-account.component.scss']
})
export class AddAccountComponent implements OnInit {
  result : any;
  res :string;
  insert(addAccount : NgForm) {
    //this.account.accountNumber = this.accountNumber;
    this._accountSerivce.addAccount(this.account).subscribe(x =>{
      this.result=x;
    alert(x);
  
  })
  alert(this.result);
}

accountNumber :number;
firstName :String;
lastName:String;
gender:String;
city:String;
state:String;
mob:String;
email:String;
balance:String;
cheqFacil:String;
accountType:String;
status:String;
account : Account;
  constructor(private _accountSerivce:AccountService 
    ) {this.account = new Account();
      //this.accountNumber = parseInt(localStorage.getItem("accountNumber")); 
    }

  ngOnInit(): void {
  }

}
