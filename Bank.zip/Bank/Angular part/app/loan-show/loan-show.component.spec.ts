import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LoanShowComponent } from './loan-show.component';

describe('LoanShowComponent', () => {
  let component: LoanShowComponent;
  let fixture: ComponentFixture<LoanShowComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LoanShowComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LoanShowComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
