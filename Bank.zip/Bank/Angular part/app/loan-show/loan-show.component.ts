import { Component, OnInit } from '@angular/core';
import { Loan } from '../loan';
import { LoanService } from '../loan.service';
import { ActivatedRoute, Router } from '@angular/router';
@Component({
  selector: 'app-loan-show',
  templateUrl: './loan-show.component.html',
  styleUrls: ['./loan-show.component.scss']
})
export class LoanShowComponent implements OnInit {

  loans: Loan[];
  loanId:number;
  loanStatus:String;
  acceptOrRejectLoan(loanId:number,loanStatus:String){
    this.loanId=loanId
    this.loanStatus=loanStatus;
    localStorage.setItem("loanId",this.loanId.toString());
   localStorage.setItem("loanStatus",this.loanStatus.toString());
   this._router.navigate(['../accept-or-reject-loan.html'], {relativeTo: this._route});
  }
  constructor(private _loanService :LoanService,private _route : ActivatedRoute,private _router : Router) { 
    this._loanService.showLoan().subscribe({
      next: rs =>{
        this.loans = rs;
      }
    })
  }
 

  ngOnInit(): void {
  }

}
