import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule } from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';


import { CustomerComponent } from './customer/customer.component';
import { HomepageComponent } from './homepage/homepage.component';
import { AccountLoginComponent } from './account-login/account-login.component';
import { AccountDashBoardComponent } from './account-dash-board/account-dash-board.component';
import { AdminDashBoardComponent } from './admin-dash-board/admin-dash-board.component';
import { AccountShowComponent } from './account-show/account-show.component';
import { AdminShowComponent } from './admin-show/admin-show.component';
import { AcceptOrRejectLoanComponent } from './accept-or-reject-loan/accept-or-reject-loan.component';
import { ApplyLoanComponent } from './apply-loan/apply-loan.component';
import { LoanShowComponent } from './loan-show/loan-show.component';
import { PlaceTransactionComponent } from './place-transaction/place-transaction.component';
import { TransactionShowComponent } from './transaction-show/transaction-show.component';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { SearchLoanComponent } from './search-loan/search-loan.component';
import { UpdateAccountComponent } from './update-account/update-account.component';
import { SearchAccountComponent } from './search-account/search-account.component';
import { AccountBalanceComponent } from './account-balance/account-balance.component';
import { SearchAdminComponent } from './search-admin/search-admin.component';
import { SearchTransactionComponent } from './search-transaction/search-transaction.component';
import { AddAccountComponent } from './add-account/add-account.component';
import { PendingLoansComponent } from './pending-loans/pending-loans.component';
import { CreditComponent } from './credit/credit.component';
import { DebitComponent } from './debit/debit.component';
import { AboutusComponent } from './aboutus/aboutus.component';


const appRoutes : Routes = [
  {path:'',component:HomepageComponent},
  {path:'accountLogin',component:AccountLoginComponent},
  {path:'addAccount',component:AddAccountComponent},
  {path:'adminLogin',component:AdminLoginComponent},
  {path:'aboutus',component:AboutusComponent},
  {path:'accountDashBoard',component:AccountDashBoardComponent},
  {path:'adminDashBoard',component:AdminDashBoardComponent},
  {path:'accoDashBobard',component:AccountDashBoardComponent, 
  children : [
    // {path:'showRestaurant',component:RestaurentShowComponent,outlet:'mphasis'},
     {path:'searchAccount',component:SearchAccountComponent,outlet:'mphasis'},
     {path:'showBalance',component:AccountBalanceComponent,outlet:'mphasis'},
     {path:'applyLoan',component:ApplyLoanComponent,outlet:'mphasis'},
     {path:'searchLoan',component:SearchLoanComponent,outlet:'mphasis'},
     {path:'searchTransaction',component:SearchTransactionComponent,outlet:'mphasis'},
     {path:'updateAccount',component:UpdateAccountComponent,outlet:'mphasis'},
     {path:'placeTransaction',component:PlaceTransactionComponent,outlet:'mphasis'},
     {path:'debit',component:DebitComponent,outlet:'mphasis'},
     {path:'credit',component:CreditComponent,outlet:'mphasis'},
     
    
    // {path:'searchCustomerOrder',component:OrderShowComponent,outlet:'mphasis'},
    // {path:'showCustomerPendingOrder',component:OrderShowComponent,outlet:'mphasis'},
    // {path:'searchWallet',component:WalletShowComponent,outlet:'mphasis'},
    // {path:'placeOrder',component:PlaceOrderComponent,outlet:'mphasis'},
    //{path:'',component:HomepageComponentageComponent},

  ]
  
},
{path:'admiDashBobard',component:AdminDashBoardComponent,
  children : [
    {path:'showAdmin',component:AdminShowComponent,outlet:'mphasis'},
    {path:'showLoan',component:LoanShowComponent,outlet:'mphasis'},
    {path:'showAccount',component:AccountShowComponent,outlet:'mphasis'},
    {path:'showTransaction',component:TransactionShowComponent,outlet:'mphasis'},
    {path:'searchAdmin',component:SearchAdminComponent,outlet:'mphasis'},
    {path:'acceptOrRejectLoan',component:AcceptOrRejectLoanComponent,outlet:'mphasis'},
    {path:'showPendingLoan',component:PendingLoansComponent,outlet:'mphasis'},
    // {path:'searchAdmin',component:RestaurentShowComponent,outlet:'mphasis'},
    // {path:'showCustomer',component:CustomerShowComponent,outlet:'mphasis'},
    // {path:'searchVendorOrder',component:OrderShowComponent,outlet:'mphasis'},
    // {path:'showVendorPendingOrder',component:OrderShowComponent,outlet:'mphasis'},
    // {path:'acceptOrReject',component:AcceptOrRejectComponent,outlet:'mphasis'},
  ]
}


]

@NgModule({
  declarations: [
    AppComponent,
    CustomerComponent,
    HomepageComponent,
    AccountLoginComponent,
    AccountDashBoardComponent,
    AdminDashBoardComponent,
    AccountShowComponent,
    AdminShowComponent,
    AcceptOrRejectLoanComponent,
    ApplyLoanComponent,
    LoanShowComponent,
    PlaceTransactionComponent,
    TransactionShowComponent,
    AdminLoginComponent,
    SearchLoanComponent,
    UpdateAccountComponent,
    SearchAccountComponent,
    AccountBalanceComponent,
    SearchAdminComponent,
    SearchTransactionComponent,
    AddAccountComponent,
    PendingLoansComponent,
    CreditComponent,
    DebitComponent,
    AboutusComponent,
    
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot(appRoutes),
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
