import { Component, OnInit } from '@angular/core';
import { LoanService } from '../loan.service';
import { Loan } from '../loan';
@Component({
  selector: 'app-pending-loans',
  templateUrl: './pending-loans.component.html',
  styleUrls: ['./pending-loans.component.scss']
})
export class PendingLoansComponent implements OnInit {
  loans: Loan[];
  loanId:number;
  loanStatus:String;
  constructor(private _loanService :LoanService) { 
    this._loanService.showPendingLoan().subscribe({
      next: rs =>{
        this.loans = rs;
      }
    })
  }

  ngOnInit(): void {
  }

}
