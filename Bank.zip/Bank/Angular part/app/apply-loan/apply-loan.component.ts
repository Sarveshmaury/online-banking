import { Component, OnInit } from '@angular/core';
import { Loan } from '../loan';
import { NgForm } from '@angular/forms';
import { LoanService } from '../loan.service';
@Component({
  selector: 'app-apply-loan',
  templateUrl: './apply-loan.component.html',
  styleUrls: ['./apply-loan.component.scss']
})
export class ApplyLoanComponent implements OnInit {
  result : any;
  res :string;
  insert(placeOrder : NgForm) {
    this.loan.accountNumber = this.accountNumber;
    this._loanSerivce.applyLoan(this.loan).subscribe(x =>{
      this.result=x;
    alert(x);
  
  })
  alert(this.result);
}
accountNumber :number;
loanApplyFor:String ;
loanAmount:number;
loan : Loan;


  constructor(private _loanSerivce:LoanService 
) {this.loan = new Loan();
  this.accountNumber = parseInt(localStorage.getItem("accountNumber"));
 // this._walletService.showCustomerWallet(this.cid).subscribe(x => {
   // this.wallets = x;
  //});
 }

  ngOnInit(): void {
  }

}
