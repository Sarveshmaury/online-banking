import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AcceptOrRejectLoanComponent } from './accept-or-reject-loan.component';

describe('AcceptOrRejectLoanComponent', () => {
  let component: AcceptOrRejectLoanComponent;
  let fixture: ComponentFixture<AcceptOrRejectLoanComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AcceptOrRejectLoanComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AcceptOrRejectLoanComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
