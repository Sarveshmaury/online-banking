import { Component, OnInit } from '@angular/core';
import { LoanService } from '../loan.service';
import { Loan } from '../loan';

@Component({
  selector: 'app-accept-or-reject-loan',
  templateUrl: './accept-or-reject-loan.component.html',
  styleUrls: ['./accept-or-reject-loan.component.scss']
})
export class AcceptOrRejectLoanComponent implements OnInit {

  loanId :number;
  loanStatus : string;
  result : string;
  loan:Loan[];
  acceptOrRejectLoan() {
    this._loanService.acceptOrRejectLoan(this.loanId,this.loanStatus).subscribe(
      (      x: string) =>{
        this.result = x;

      }
    ) 
    alert(this.result);
  }
  constructor(private _loanService : LoanService) {
    
      this.loanId = parseInt(localStorage.getItem("loanId"));
     // this.vendorId = parseInt(localStorage.getItem("vendorId"));
     this._loanService.showLoan().subscribe({
      next: rs =>{
        this.loan = rs;
      }
    })
     }

  ngOnInit(): void {
  }

}
