import { Component, OnInit } from '@angular/core';
import { Account } from '../account';
import { AccountService } from '../account.service';
@Component({
  selector: 'app-search-account',
  templateUrl: './search-account.component.html',
  styleUrls: ['./search-account.component.scss']
})
export class SearchAccountComponent implements OnInit {

  accountNumber : number;
  account : Account;
  constructor(private _accountService : AccountService) { 
    this.accountNumber =parseInt(localStorage.getItem("accountNumber"));
    this._accountService.searchAccount(this.accountNumber).subscribe(x => {
      this.account=x;
    })
  }

  ngOnInit(): void {
  }

}
