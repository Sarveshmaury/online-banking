import { Component, OnInit } from '@angular/core';
import { Admin } from '../admin';
import { AdminService } from '../admin.service';
import { Router } from '@angular/router';
import { Account } from '../account';
@Component({
  selector: 'app-admin-login',
  templateUrl: './admin-login.component.html',
  styleUrls: ['./admin-login.component.scss']
})
export class AdminLoginComponent implements OnInit {

  adminId : number;
  passCode : string;
  admins : Admin[];
  logMe() {
    localStorage.setItem('adminId',this.adminId.toString());
    if(this.passCode=="Mphasis") {
      this._router.navigate(['/adminDashBoard']);
    }
  }
  constructor(private _router : Router, private _adminService :AdminService) { 
    this._adminService.showAdmin().subscribe({
      next: rs =>{
        this.admins = rs;
      }
    })
  }
  ngOnInit(): void {
  }

}
