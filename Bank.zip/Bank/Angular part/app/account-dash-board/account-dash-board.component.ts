import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Account } from '../account';
import { AccountService } from '../account.service';

@Component({
  selector: 'app-account-dash-board',
  templateUrl: './account-dash-board.component.html',
  styleUrls: ['./account-dash-board.component.scss']
})
export class AccountDashBoardComponent implements OnInit {

  accountNumber : number;
  account : Account;
  constructor(private _accountService : AccountService) { 
    this.accountNumber =parseInt(localStorage.getItem("accountNumber"));
    this._accountService.searchAccount(this.accountNumber).subscribe(x => {
      this.account=x;
    })
  }

  ngOnInit(): void {
  }

}
