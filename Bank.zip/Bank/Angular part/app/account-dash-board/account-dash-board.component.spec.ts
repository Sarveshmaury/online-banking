import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AccountDashBoardComponent } from './account-dash-board.component';

describe('AccountDashBoardComponent', () => {
  let component: AccountDashBoardComponent;
  let fixture: ComponentFixture<AccountDashBoardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AccountDashBoardComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AccountDashBoardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
