import { Component, OnInit } from '@angular/core';
import { Transaction } from '../transaction';
import { TransactionService } from '../transaction.service';

@Component({
  selector: 'app-search-transaction',
  templateUrl: './search-transaction.component.html',
  styleUrls: ['./search-transaction.component.scss']
})
export class SearchTransactionComponent implements OnInit {

  accountNumber : number;
  transaction :Transaction[];
  constructor(private _transactionService : TransactionService) { 
    this.accountNumber =parseInt(localStorage.getItem("accountNumber"));
    this._transactionService.searchTransaction(this.accountNumber).subscribe({next:rs=>{this.transaction=rs;}}
    )
  }

  ngOnInit(): void {
  }

}
