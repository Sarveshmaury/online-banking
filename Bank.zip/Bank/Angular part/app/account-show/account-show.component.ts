import { Component, OnInit } from '@angular/core';
import { Account } from '../account';
import { AccountService } from '../account.service';

@Component({
  selector: 'app-account-show',
  templateUrl: './account-show.component.html',
  styleUrls: ['./account-show.component.scss']
})
export class AccountShowComponent implements OnInit {

  accounts : Account[];
  constructor(private _accountService :AccountService) {
  this._accountService.showAccount().subscribe({
    next: rs =>{
      this.accounts = rs;
    }
  })
}

  ngOnInit(): void {
  }

}
