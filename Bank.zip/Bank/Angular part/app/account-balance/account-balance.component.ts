import { Component, OnInit } from '@angular/core';
import { Account } from '../account';
import { AccountService } from '../account.service';

@Component({
  selector: 'app-account-balance',
  templateUrl: './account-balance.component.html',
  styleUrls: ['./account-balance.component.scss']
})
export class AccountBalanceComponent implements OnInit {
  accountNumber : number;
  account : Account;
  constructor(private _accountService : AccountService) { 
    this.accountNumber =parseInt(localStorage.getItem("accountNumber"));
    this._accountService.showBalance(this.accountNumber).subscribe(x => {
      this.account=x;
    })
  }

  ngOnInit(): void {
  }

}
