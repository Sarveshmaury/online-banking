export class Transaction {
    public tranId : number;
    public accountNumber : number;
    public tranAmount : number;
    public tranType : string;
    public tranDate : Date;
  
    constructor(){

    }
}
