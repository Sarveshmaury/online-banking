export class Customer {
}
