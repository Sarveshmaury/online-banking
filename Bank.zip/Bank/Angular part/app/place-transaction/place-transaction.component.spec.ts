import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PlaceTransactionComponent } from './place-transaction.component';

describe('PlaceTransactionComponent', () => {
  let component: PlaceTransactionComponent;
  let fixture: ComponentFixture<PlaceTransactionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PlaceTransactionComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PlaceTransactionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
