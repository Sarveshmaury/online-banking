import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Account } from '../account';
import { UpdateAccountService } from '../update-account.service';
@Component({
  selector: 'app-update-account',
  templateUrl: './update-account.component.html',
  styleUrls: ['./update-account.component.scss']
})
export class UpdateAccountComponent implements OnInit {
  result : any;
  res :string;
  insert(updateAccount : NgForm) {
    this.account.accountNumber = this.accountNumber;
    this._updateAccountSerivce.updateAccount(this.account).subscribe(x =>{
      this.result=x;
    alert(x);
  
  })
  alert(this.result);
}

accountNumber :number;
firstName :String;
lastName:String;
gender:String;
city:String;
state:String;
mob:String;
email:String;
balance:String;
cheqFacil:String;
accountType:String;
status:String;
account : Account;


  constructor(private _updateAccountSerivce:UpdateAccountService 
) {this.account = new Account();
  this.accountNumber = parseInt(localStorage.getItem("accountNumber"));
 // this._walletService.showCustomerWallet(this.cid).subscribe(x => {
   // this.wallets = x;
  //});
 }

  ngOnInit(): void {
  }

}
