export class Admin { 
    public adminId : number;
    public adminName : string;
    public adminGender : string;
    public adminCity: string;
    public adminState : string;
    public adminMob : string;
    public adminEmail :string;
    constructor(){

    }
}
