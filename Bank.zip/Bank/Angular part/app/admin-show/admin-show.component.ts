import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-show',
  templateUrl: './admin-show.component.html',
  styleUrls: ['./admin-show.component.scss']
})
export class AdminShowComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
